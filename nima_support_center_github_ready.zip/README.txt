Nima Support Center

Upload the file named index.html to your GitHub repository root.
Repository: Nima
GitHub Pages source: main / root

This version includes:
- 7-second Connecting to Nima intro
- cartoon avatar
- office photo background
- embedded audio message
- click-to-reveal answer buttons
